#Analiza componentelor principale

#index_col = index-ul se realizeaza in functie de coloana "Country_Number"
#data = pd.read_csv('dataIN/MiseNatPopTari.csv',index_col=0)

#1. salvarea tarilor in care rata sporului natural este negativ

#facem lista cu COLOANELE a caror valori ne intereseaza
#pt ca avem index_col=0, prima coloana nu se mai pune la numaratoare pt ca e index
#[1:]-->country_number nu se pune ca e index, 0 devine Country_Name iar noi incepem de la 1 pana la final
# adica de la Three_Letter_Country_Code pana la utima coloana
#se extrag doar NUMELE coloanelor

#nume_variabile=list(data.columns)[1:]

#extragem din nou numele coloanelor exceptand prima coloana(0)
#practic coloanele relevante(de la RS pana la final)
#numeric_var = nume_variabile[1:]

#extragem valorile din coloana Country_Name
#nume_instante = list(data['Country_Name'].values)

#aplicam conditia ca rs sa fie negativa
#conditie=data['RS'] < 0
#result = data[conditie]

#result.to_csv('dataOUT/cerinta1.csv')

#2.salvarea a valorilor medii pentru indicatorii de mai sus, la nivel de continent.

#index-ul este coloana 0= Country_Number
#coduri_tari=pd.read_csv('dataIN/CoduriTariExtins.csv',index_col=0)

#aux=data.merge(right=coduri_tari,left_index=True,right_index=True)

#facem csv ul result2
#result2 = aux[numeric_var + ['Contintent']].groupby(by='Continent').mean()

#result2.to_csv('dataOUT/cerinta2.csv')

#ANALIZA COMPONENTELOR PRINCIPALE

#cerinta1: Variantele componentelor principale
#importam libraria asta
from sklearn.decomposition import PCA
import pandas as pd
import numpy as np

dataCSV = pd.read_csv('dataIN/MiseNatPopTari.csv',index_col=0)

#extragem valorile din coloana Country_Name
nume_instante = list(dataCSV['Country_Name'].values)

#facem lista cu COLOANELE a caror valori ne intereseaza
#pt ca avem index_col=0, prima coloana nu se mai pune la numaratoare pt ca e index
#[1:]-->country_number nu se pune ca e index, 0 devine Country_Name iar noi incepem de la 1 pana la final
# adica de la Three_Letter_Country_Code pana la utima coloana
#se extrag doar NUMELE coloanelor
denumire_variabile=list(dataCSV.columns)[1:]

#extragem din nou numele coloanelor exceptand prima coloana(0)
#practic coloanele relevante(de la RS pana la final)
variabile_numerice = denumire_variabile[1:]

#normalizare datelor
# data[variabile_numerice] = datele extrase din coloanele de interes
# din fiecare variabila scadem media si abateria standard
#practic se efectueaza standardizarea(Sau normalizarea z-score)
data_std = (dataCSV[variabile_numerice] - dataCSV[variabile_numerice].mean())/dataCSV[variabile_numerice].std()

#facem obiectul PCA()
model = PCA()

#calculam componentele principale si le stocam in model
model.fit(data_std)

#calculam varianta explicativa pt fiecare componenta
variance = model.explained_variance_ratio_

#afisare rapoarte de varianta
print("B.1.")
print(variance)

#CERINTA: Scorurile asociate instantelor

#calcularea nr total componente
nr_componente = len(variance)

#se creeaza etichete pt fiecare componenta
et_componente = ["C" + str(i+1) for i in range(nr_componente)]
print(et_componente)

#se calculeaza scorurile PCA folosind datele standardizate
scores=np.dot(data_std,model.components_.T)

#creare data_frame + salvare csv
t_scores = pd.DataFrame(scores,index=nume_instante,columns=et_componente)
t_scores.to_csv('dataOUT/scoruri.csv')

#CERINTA:graficul scorurilor in primele 2 axe principala

#ca date de prelucrare vom folosi MATRICEA de componente principale in urma modelului PCA
#index= etichetele pt fiecare componenta principala adica C1,C2,C3,C4
#columns= lista de varibaile numerice initiale asociate cu fiecare coloan din matricea de comp. principale
t_componente = pd.DataFrame(data=model.components_, index=et_componente, columns=variabile_numerice)
print(t_componente)

#CLASA PT GRAFICE
from matplotlib import pyplot as plt

#t = t_componente(adica = DataFrame ul care contine comp principale si variabilelel numerice
# x= nr var pe axa X
# y= nr var pe axa Y
def plot_componente(t,x,y,title="Componente"):
    #9x9 inch, optional
    fig = plt.figure(title,figsize=(9,9))

    #se adauga un subplot(adica o axa)
    #(1,1,1) --> avem un singur subplot in figura
    ax = fig.add_subplot(1,1,1)

    #setam etichetele pt axele x si y(x si y sunt numele variabilelor care vor afisate pe axele respective)
    ax.set_xlabel(x, fontdict={"fontsize": 12, "color": "b"})
    ax.set_ylabel(y, fontdict={"fontsize":12, "color": "b"})
    print(t)

    #adaugare scatter plot pe axa creata anterior
    ax.scatter(t.loc[x],t.loc[y],color='r')

    #eticheta pt fiecare punct din scatter plot
    for var in variabile_numerice:
        #print(var)
        #t.loc[x].loc[var] = acceseaza o valoare
        #.loc[x] = accesare rand
        #.loc[var]=valoarea specifica
        ax.text(t.loc[x].loc[var], t.loc[y].loc[var],var)

plot_componente(t_componente,'C1','C2')
plt.show()










